<#
.SYNOPSIS
    Walk Break for Windows. A system-tray timer that alternates 40 minutes of
    work with a 5-minute movement break.

.DESCRIPTION
    This is the Windows version of the macOS menu-bar app. It uses only what
    ships with Windows 10 and 11 (Windows PowerShell 5.1, Windows Forms and
    GDI+), so there is nothing to compile or download.

    The pixel-art rabbit types during work and hops during the break. The break
    window opens automatically at both transitions. Closing it leaves the
    countdown running. Each break shows three movement ideas, rotating through
    all 35 combinations of the seven activities.

.PARAMETER ExportIcon
    Writes the app icon as an .ico file to the given path and exits. The
    installer uses this for the Start menu shortcut.
#>
[CmdletBinding()]
param(
    [string]$ExportIcon
)

$ErrorActionPreference = 'Stop'

# Windows Forms needs Windows PowerShell 5.1 on an STA thread. Relaunch there if
# someone starts the script from PowerShell 7 or an MTA host.
$isCore = $PSVersionTable.PSEdition -eq 'Core'
$isSta = [Threading.Thread]::CurrentThread.GetApartmentState() -eq [Threading.ApartmentState]::STA
if ($isCore -or -not $isSta) {
    $windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $relaunch = @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-STA', '-File', "`"$PSCommandPath`"")
    if ($ExportIcon) {
        $relaunch += @('-ExportIcon', "`"$ExportIcon`"")
        Start-Process -FilePath $windowsPowerShell -ArgumentList $relaunch -Wait -NoNewWindow
    } else {
        Start-Process -FilePath $windowsPowerShell -ArgumentList (@('-WindowStyle', 'Hidden') + $relaunch) -WindowStyle Hidden
    }
    exit
}

Add-Type -AssemblyName System.Windows.Forms, System.Drawing

if (-not ('WalkBreak.Native' -as [type])) {
    Add-Type -ReferencedAssemblies System.Windows.Forms, System.Drawing -TypeDefinition @'
using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace WalkBreak
{
    public class BufferedPanel : Panel
    {
        public BufferedPanel()
        {
            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer |
                     ControlStyles.UserPaint | ControlStyles.ResizeRedraw, true);
        }
    }

    public class PopupForm : Form
    {
        private readonly bool noActivate;

        public PopupForm(bool noActivate)
        {
            this.noActivate = noActivate;
            FormBorderStyle = FormBorderStyle.None;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.Manual;
            AutoScaleMode = AutoScaleMode.None;
            DoubleBuffered = true;
        }

        // The break window must not steal keyboard focus from whatever the
        // person is typing into, like the non-activating panel on macOS.
        protected override bool ShowWithoutActivation
        {
            get { return noActivate; }
        }

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                cp.ExStyle |= 0x00000080; // WS_EX_TOOLWINDOW: no taskbar button, no Alt+Tab entry
                cp.ExStyle |= 0x00000008; // WS_EX_TOPMOST
                if (noActivate)
                {
                    cp.ExStyle |= 0x08000000; // WS_EX_NOACTIVATE
                }
                return cp;
            }
        }

        protected override void OnHandleCreated(EventArgs e)
        {
            base.OnHandleCreated(e);
            try
            {
                int round = 2; // DWMWCP_ROUND on Windows 11; ignored on Windows 10
                Native.DwmSetWindowAttribute(Handle, 33, ref round, 4);
            }
            catch
            {
            }
        }
    }

    public static class Native
    {
        [DllImport("kernel32.dll")]
        public static extern IntPtr GetConsoleWindow();

        [DllImport("kernel32.dll")]
        public static extern uint GetConsoleProcessList(uint[] processList, uint processCount);

        [DllImport("user32.dll")]
        public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        [DllImport("user32.dll")]
        public static extern bool SetForegroundWindow(IntPtr hWnd);

        [DllImport("user32.dll")]
        public static extern bool SetProcessDPIAware();

        [DllImport("user32.dll")]
        private static extern bool SystemParametersInfo(uint action, uint param, ref bool value, uint winIni);

        [DllImport("dwmapi.dll")]
        public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attribute, ref int value, int size);

        // Mirrors the Reduce Motion setting on macOS. Windows calls it
        // "Animation effects" under Settings > Accessibility > Visual effects.
        public static bool AnimationsEnabled()
        {
            bool enabled = true;
            try
            {
                SystemParametersInfo(0x1042, 0, ref enabled, 0); // SPI_GETCLIENTAREAANIMATION
            }
            catch
            {
            }
            return enabled;
        }

        public static bool OwnsConsoleAlone()
        {
            try
            {
                uint[] list = new uint[4];
                return GetConsoleProcessList(list, 4) <= 1;
            }
            catch
            {
                return false;
            }
        }
    }
}
'@
}

# ---------------------------------------------------------------------------
# Paths, logging and scaling
# ---------------------------------------------------------------------------

$script:DataDir = Join-Path $env:APPDATA 'WalkBreak'
$script:StateFile = Join-Path $script:DataDir 'state.json'
$script:LogFile = Join-Path $script:DataDir 'walkbreak.log'

function Write-WalkBreakLog([string]$Message) {
    try {
        New-Item -ItemType Directory -Force -Path $script:DataDir | Out-Null
        Add-Content -LiteralPath $script:LogFile -Value ('{0:u} {1}' -f (Get-Date), $Message)
    } catch {
    }
}

[void][WalkBreak.Native]::SetProcessDPIAware()
$script:Scale = 1.0
try {
    $screenGraphics = [Drawing.Graphics]::FromHwnd([IntPtr]::Zero)
    $script:Scale = $screenGraphics.DpiX / 96.0
    $screenGraphics.Dispose()
} catch {
}

function Px([double]$Value) {
    [int][math]::Round($Value * $script:Scale, [MidpointRounding]::AwayFromZero)
}

function Div([int]$A, [int]$B) {
    [int][math]::Floor($A / $B)
}

function ColorOf([int]$Hex) {
    [Drawing.Color]::FromArgb(255, ($Hex -shr 16) -band 255, ($Hex -shr 8) -band 255, $Hex -band 255)
}

$script:Brushes = @{}
function Get-Brush([int]$Hex) {
    if (-not $script:Brushes.ContainsKey($Hex)) {
        $script:Brushes[$Hex] = [Drawing.SolidBrush]::new((ColorOf $Hex))
    }
    $script:Brushes[$Hex]
}

function Paint-Pixels($Graphics, [int]$Hex, [int]$X, [int]$Y, [int]$Width = 1, [int]$Height = 1) {
    if ($Width -le 0 -or $Height -le 0) { return }
    $Graphics.FillRectangle((Get-Brush $Hex), $X, $Y, $Width, $Height)
}

function New-Font([string]$Family, [double]$Pixels, [Drawing.FontStyle]$Style = [Drawing.FontStyle]::Regular) {
    [Drawing.Font]::new($Family, [single]($Pixels * $script:Scale), $Style, [Drawing.GraphicsUnit]::Pixel)
}

# ---------------------------------------------------------------------------
# Break cycle (same rules as BreakCycle.swift)
# ---------------------------------------------------------------------------

$script:WorkSeconds = 40 * 60
$script:WalkSeconds = 5 * 60
$script:Session = $null
$script:Testing = $false

function Get-PhaseDuration([string]$Phase) {
    if ($Phase -eq 'work') { $script:WorkSeconds } else { $script:WalkSeconds }
}

function Start-Phase([string]$Phase, [double]$Duration, [datetime]$Now) {
    $script:Session = @{ Phase = $Phase; EndsAt = $Now.AddSeconds($Duration); Duration = $Duration }
}

function Start-Cycle([datetime]$Now, [bool]$Test) {
    $script:Testing = $Test
    $duration = if ($Test) { 5 } else { $script:WorkSeconds }
    Start-Phase 'work' $duration $Now
}

function Stop-Cycle {
    $script:Session = $null
    $script:Testing = $false
}

function Step-CycleIfDue([datetime]$Now) {
    $session = $script:Session
    if ($null -eq $session -or $Now -lt $session.EndsAt) { return $null }
    $phase = if ($session.Phase -eq 'work') { 'walk' } else { 'work' }
    # After sleep or a delayed tick, give the new phase its full time.
    $duration = if ($script:Testing -and $phase -eq 'walk') { 20 } else { Get-PhaseDuration $phase }
    if ($phase -eq 'work') { $script:Testing = $false }
    Start-Phase $phase $duration $Now
    $phase
}

function Get-SecondsRemaining([datetime]$Now) {
    $session = $script:Session
    if ($null -eq $session) { return $script:WorkSeconds }
    $remaining = ($session.EndsAt - $Now).TotalSeconds
    [int][math]::Ceiling([math]::Min($session.Duration, [math]::Max(0, $remaining)))
}

# ---------------------------------------------------------------------------
# Movement rotation (same rules as MovementRotation.swift)
# ---------------------------------------------------------------------------

$script:Movements = @(
    '100 hops', '10 squats', '10 lunges per leg', 'Rotate your waist',
    ('Cat{0}cow' -f [char]0x2013), 'Plank walk to downward-facing dog', 'Just walk'
)

$script:MovementGroups = [Collections.ArrayList]::new()
for ($first = 0; $first -lt $script:Movements.Count; $first++) {
    for ($second = $first + 1; $second -lt $script:Movements.Count; $second++) {
        for ($third = $second + 1; $third -lt $script:Movements.Count; $third++) {
            [void]$script:MovementGroups.Add(@($first, $second, $third))
        }
    }
}

function Read-RotationState {
    $state = @{ Queue = @(); Last = $null }
    try {
        if (Test-Path -LiteralPath $script:StateFile) {
            $json = Get-Content -LiteralPath $script:StateFile -Raw | ConvertFrom-Json
            if ($null -ne $json.queue) { $state.Queue = @($json.queue | ForEach-Object { [int]$_ }) }
            if ($null -ne $json.lastGroup) { $state.Last = [int]$json.lastGroup }
        }
    } catch {
        Write-WalkBreakLog "Could not read $($script:StateFile): $($_.Exception.Message)"
    }
    $state
}

function Save-RotationState($Queue, [int]$Last) {
    try {
        New-Item -ItemType Directory -Force -Path $script:DataDir | Out-Null
        $data = [ordered]@{ queue = [int[]]@($Queue); lastGroup = $Last }
        $data | ConvertTo-Json -Compress | Set-Content -LiteralPath $script:StateFile -Encoding UTF8
    } catch {
        Write-WalkBreakLog "Could not save $($script:StateFile): $($_.Exception.Message)"
    }
}

function Get-NextMovements([bool]$IsTest) {
    if ($IsTest) {
        return @(Get-Random -InputObject $script:Movements -Count 3)
    }

    $state = Read-RotationState
    $queue = @($state.Queue)
    $groupCount = $script:MovementGroups.Count
    $outOfRange = @($queue | Where-Object { $_ -lt 0 -or $_ -ge $groupCount }).Count -gt 0
    $hasDuplicates = @($queue | Select-Object -Unique).Count -ne $queue.Count
    if ($queue.Count -eq 0 -or $outOfRange -or $hasDuplicates) {
        $queue = @(Get-Random -InputObject (0..($groupCount - 1)) -Count $groupCount)
        if ($null -ne $state.Last -and $queue[0] -eq $state.Last) {
            $queue[0], $queue[1] = $queue[1], $queue[0]
        }
    }

    $index = [int]$queue[0]
    $rest = @()
    if ($queue.Count -gt 1) { $rest = @($queue[1..($queue.Count - 1)]) }
    Save-RotationState $rest $index

    $group = $script:MovementGroups[$index]
    @(Get-Random -InputObject $group -Count 3 | ForEach-Object { $script:Movements[$_] })
}

# ---------------------------------------------------------------------------
# Pixel art (ported from PixelMeadow.swift and MakeIcon.swift)
# ---------------------------------------------------------------------------

$script:RabbitRows = @(
    '.............oo....',
    '............owpo...',
    '...........owpo....',
    '..........owpo.oo..',
    '..........owo.owo..',
    '..........owoowo...',
    '..........owwwo....',
    '...oo.....owwwwoo..',
    '..owwo.ooowwwowwo..',
    '..owwoowwwwwwwwwwo.',
    '...oowwwwwwwwwwpo..',
    '....owwwwwwwsooo...',
    '....owwwwwssoo.....',
    '.....osssowwwo.....',
    '.....owwwoooo......',
    '.....oooo..........'
)
$script:RabbitPalette = @{ 'o' = 0x4E435A; 'w' = 0xFFF1DD; 'p' = 0xE69BB7; 's' = 0xCBBBC5 }

function New-RabbitBitmap([bool]$FacingRight) {
    $bitmap = [Drawing.Bitmap]::new(19, 16, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    for ($row = 0; $row -lt 16; $row++) {
        $line = $script:RabbitRows[$row]
        for ($column = 0; $column -lt 19; $column++) {
            $key = [string]$line[$column]
            if (-not $script:RabbitPalette.ContainsKey($key)) { continue }
            $x = if ($FacingRight) { $column } else { 18 - $column }
            $bitmap.SetPixel($x, $row, (ColorOf $script:RabbitPalette[$key]))
        }
    }
    $bitmap
}

function New-SceneGraphics([Drawing.Bitmap]$Bitmap) {
    $graphics = [Drawing.Graphics]::FromImage($Bitmap)
    $graphics.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
    $graphics.PixelOffsetMode = [Drawing.Drawing2D.PixelOffsetMode]::Half
    $graphics.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::None
    $graphics
}

function Draw-Sprite($Graphics, [Drawing.Bitmap]$Sprite, [int]$X, [int]$Y) {
    $Graphics.DrawImage($Sprite, [Drawing.Rectangle]::new($X, $Y, $Sprite.Width, $Sprite.Height))
}

function New-MeadowBackground {
    $bitmap = [Drawing.Bitmap]::new(128, 52, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = New-SceneGraphics $bitmap
    Paint-Pixels $g 0xA5CEE2 0 0 128 52

    foreach ($cloud in @(@(3, 8, 26), @(40, 3, 18), @(70, 13, 22), @(101, 7, 21))) {
        $x = $cloud[0]; $y = $cloud[1]; $width = $cloud[2]
        Paint-Pixels $g 0xE9C9E0 $x $y $width 5
        Paint-Pixels $g 0xE9C9E0 ($x + 5) ($y - 3) ($width - 9) 4
        Paint-Pixels $g 0xF8E6EB ($x + 5) ($y - 3) ($width - 11) 1
    }

    for ($x = 0; $x -lt 128; $x++) {
        $left = 14 + (Div ([math]::Abs($x - 27)) 2)
        $right = 16 + (Div ([math]::Abs($x - 103)) 2)
        $ridge = [math]::Min([math]::Min($left, $right), 37)
        if (($x % 7) -gt 3) { $ridge += 1 }
        Paint-Pixels $g 0x7090C1 $x $ridge 1 (40 - $ridge)
        if ($ridge -lt 24) {
            Paint-Pixels $g 0xC4E0E5 $x $ridge 1 (3 + ($x % 5))
        }
        $hill = 32 + (Div ([math]::Abs(60 - $x)) 18) + (Div ($x % 11) 7)
        Paint-Pixels $g 0x6F9A82 $x $hill 1 (42 - $hill)
        $meadow = 37 + ((Div $x 7) % 3)
        Paint-Pixels $g 0x9ABD72 $x $meadow 1 (52 - $meadow)
        Paint-Pixels $g 0x608F63 $x (47 + (($x * 7) % 4)) 1 5
    }

    for ($x = 2; $x -lt 128; $x += 3) {
        $y = 47 + (($x * 7) % 4)
        Paint-Pixels $g 0x386A57 $x $y 1 5
        if (($x % 5) -lt 2) {
            Paint-Pixels $g 0xF8D1DE ($x - 1) ($y - 1) 3 1
            Paint-Pixels $g 0xD492B5 $x $y 1 1
        }
    }
    $g.Dispose()
    $bitmap
}

function New-DeskBackground {
    $bitmap = [Drawing.Bitmap]::new(128, 52, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = New-SceneGraphics $bitmap
    Paint-Pixels $g 0xC6CDD5 0 0 128 52
    Paint-Pixels $g 0xAAB8CF 0 0 128 3
    Paint-Pixels $g 0xAAB8CF 0 32 128 4

    Paint-Pixels $g 0x345172 9 5 35 25
    Paint-Pixels $g 0xA5CEE2 11 7 31 20
    Paint-Pixels $g 0xE9C9E0 26 10 13 2
    Paint-Pixels $g 0xF8E6EB 29 9 7 1
    for ($x = 11; $x -lt 42; $x++) {
        $ridge = [math]::Min(23, 14 + (Div ([math]::Abs($x - 20)) 2))
        Paint-Pixels $g 0x7090C1 $x $ridge 1 (25 - $ridge)
        Paint-Pixels $g 0x9ABD72 $x (23 + ((Div $x 6) % 2)) 1 3
    }
    Paint-Pixels $g 0x345172 25 7 1 20
    Paint-Pixels $g 0x345172 11 16 31 1
    Paint-Pixels $g 0x7490AC 7 29 39 2

    Paint-Pixels $g 0x7D8EAC 0 36 128 16
    Paint-Pixels $g 0x8C9DB6 0 43 128 1
    Paint-Pixels $g 0x627895 6 49 116 3
    Paint-Pixels $g 0x4E526C 33 33 18 11
    Paint-Pixels $g 0x8E778D 35 34 14 7

    Paint-Pixels $g 0x456A58 108 26 2 10
    Paint-Pixels $g 0x719370 104 27 5 2
    Paint-Pixels $g 0x658A68 109 24 5 2
    Paint-Pixels $g 0x658A68 110 30 4 2
    Paint-Pixels $g 0xC88680 105 34 9 5

    Paint-Pixels $g 0x5E4D60 26 39 92 4
    Paint-Pixels $g 0xA87D77 26 39 92 2
    Paint-Pixels $g 0x5E4D60 31 43 4 9
    Paint-Pixels $g 0x5E4D60 109 43 4 9

    # The rabbit at the laptop. Only the paw and key change while typing.
    Draw-Sprite $g $script:RabbitRight 44 21
    Paint-Pixels $g 0x4E435A 64 36 26 3
    Paint-Pixels $g 0x8EA6C3 65 36 23 1
    Paint-Pixels $g 0x4E435A 72 23 22 14
    Paint-Pixels $g 0x617DA7 73 24 20 12
    Paint-Pixels $g 0x8DB8D5 74 25 18 10
    Paint-Pixels $g 0xE7E9E2 76 27 9 1
    Paint-Pixels $g 0xC7DFE3 76 29 12 1
    Paint-Pixels $g 0xC7DFE3 78 31 7 1
    Paint-Pixels $g 0x4E435A 60 34 7 3
    $g.Dispose()
    $bitmap
}

function Get-RabbitPose([double]$Elapsed, [bool]$ReduceMotion) {
    $lap = ($Elapsed % 12) / 6
    $x = if ($ReduceMotion) { 54 } else { 8 + [int][math]::Floor(92 * (1 - [math]::Abs(1 - $lap))) }
    $facingRight = $ReduceMotion -or ($lap -lt 1)
    $step = $Elapsed % 0.8
    $airborne = [math]::Min($step / 0.58, 1)
    $height = if ($ReduceMotion) { 5.0 } else { 10.0 }
    $lift = [int][math]::Round($height * [math]::Sin([math]::PI * $airborne), [MidpointRounding]::AwayFromZero)
    @{ X = $x; Lift = $lift; FacingRight = $facingRight }
}

# The app icon from MakeIcon.swift, drawn on a 32-unit grid at any pixel size.
$script:IconRabbitRows = @(
    '.....oooo.......oo..',
    '....owwpo......owpo.',
    '....owpwo.....owwpo.',
    '....owpwo....owwpo..',
    '....owwwo...owwpo...',
    '.....owwo..owwpo....',
    '.....owwo.owwoo.....',
    '.....owwwooo........',
    '.....owwwwwooo......',
    '....owwwwwwowwo.....',
    '....owwwwwwwwwo.....',
    '...owwwwwwwwwo......',
    '..owwwwwwwwso.......',
    '.owowwwwwwwo........',
    '.owowwwwwwwo........',
    '..ooswwwwwwoo.......',
    '....owwswwwwwo......',
    '.....ooooooooo......'
)
$script:IconRabbitPalette = @{ 'o' = 0x283551; 'w' = 0xFFF1DD; 'p' = 0xEAA4B4; 's' = 0xC5B6C6 }

function New-RoundedPath([single]$X, [single]$Y, [single]$Width, [single]$Height, [single]$Radius) {
    $path = [Drawing.Drawing2D.GraphicsPath]::new()
    $d = [math]::Max(1, $Radius * 2)
    $path.AddArc($X, $Y, $d, $d, 180, 90)
    $path.AddArc($X + $Width - $d, $Y, $d, $d, 270, 90)
    $path.AddArc($X + $Width - $d, $Y + $Height - $d, $d, $d, 0, 90)
    $path.AddArc($X, $Y + $Height - $d, $d, $d, 90, 90)
    $path.CloseFigure()
    $path
}

function New-AppIconBitmap([int]$Pixels, [bool]$BreakTime = $false) {
    $scale = $Pixels / 32.0
    $art = [Drawing.Bitmap]::new($Pixels, $Pixels, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [Drawing.Graphics]::FromImage($art)
    $paint = {
        param([int]$hex, [int]$x, [int]$y, [int]$w, [int]$h)
        $left = [int][math]::Round($x * $scale, [MidpointRounding]::AwayFromZero)
        $top = [int][math]::Round($y * $scale, [MidpointRounding]::AwayFromZero)
        $right = [int][math]::Round(($x + $w) * $scale, [MidpointRounding]::AwayFromZero)
        $bottom = [int][math]::Round(($y + $h) * $scale, [MidpointRounding]::AwayFromZero)
        if ($right -gt $left -and $bottom -gt $top) {
            $g.FillRectangle((Get-Brush $hex), $left, $top, $right - $left, $bottom - $top)
        }
    }

    & $paint 0x1B3F73 1 1 30 30
    if ($BreakTime) {
        & $paint 0xA9D3E3 3 3 26 26
        & $paint 0xCFEBED 3 3 26 4
        & $paint 0x9ABD72 3 23 26 6
        & $paint 0x608F63 3 27 26 2
    } else {
        & $paint 0xA9D3E3 3 3 26 26
        & $paint 0xCFEBED 3 3 26 4
        & $paint 0x82ABC3 3 23 26 6
        & $paint 0x7299B3 3 27 26 2
    }
    for ($row = 0; $row -lt $script:IconRabbitRows.Count; $row++) {
        $line = $script:IconRabbitRows[$row]
        for ($column = 0; $column -lt $line.Length; $column++) {
            $key = [string]$line[$column]
            if ($script:IconRabbitPalette.ContainsKey($key)) {
                & $paint $script:IconRabbitPalette[$key] (2 + $column) (3 + $row) 1 1
            }
        }
    }
    & $paint 0x283551 17 12 12 9
    & $paint 0x789FBD 18 13 10 7
    & $paint 0xBFE3E8 19 14 8 5
    if ($Pixels -ge 32) {
        & $paint 0x53769D 20 15 5 1
        & $paint 0x89AFC6 20 17 6 1
    }
    & $paint 0x283551 14 20 15 3
    & $paint 0x789FBD 15 20 12 1
    & $paint 0xFFF1DD 13 18 4 2
    & $paint 0xFFF1DD 14 19 5 1
    & $paint 0x283551 9 25 15 3
    & $paint 0xE3D1D4 12 26 9 1
    & $paint 0x283551 7 23 6 6
    & $paint 0x283551 20 23 6 6
    & $paint 0xCE7F99 8 24 4 4
    & $paint 0xCE7F99 21 24 4 4
    $g.Dispose()

    # Clip the square art to the rounded tile with smooth edges.
    $icon = [Drawing.Bitmap]::new($Pixels, $Pixels, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $g = [Drawing.Graphics]::FromImage($icon)
    $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $texture = [Drawing.TextureBrush]::new($art)
    $path = New-RoundedPath $scale $scale ($scale * 30) ($scale * 30) ($scale * 7)
    $g.FillPath($texture, $path)
    $path.Dispose(); $texture.Dispose(); $g.Dispose(); $art.Dispose()
    $icon
}

function Save-AppIcon([string]$Path) {
    $sizes = @(16, 20, 24, 32, 40, 48, 64, 256)
    $images = foreach ($size in $sizes) {
        $bitmap = New-AppIconBitmap $size
        $stream = [IO.MemoryStream]::new()
        $bitmap.Save($stream, [Drawing.Imaging.ImageFormat]::Png)
        $bitmap.Dispose()
        , $stream.ToArray()
    }

    $directory = Split-Path -Parent $Path
    if ($directory) { New-Item -ItemType Directory -Force -Path $directory | Out-Null }
    $file = [IO.File]::Create($Path)
    $writer = [IO.BinaryWriter]::new($file)
    try {
        $writer.Write([uint16]0)
        $writer.Write([uint16]1)
        $writer.Write([uint16]$sizes.Count)
        $offset = 6 + 16 * $sizes.Count
        for ($i = 0; $i -lt $sizes.Count; $i++) {
            $dimension = if ($sizes[$i] -ge 256) { 0 } else { $sizes[$i] }
            $writer.Write([byte]$dimension)
            $writer.Write([byte]$dimension)
            $writer.Write([byte]0)
            $writer.Write([byte]0)
            $writer.Write([uint16]1)
            $writer.Write([uint16]32)
            $writer.Write([uint32]$images[$i].Length)
            $writer.Write([uint32]$offset)
            $offset += $images[$i].Length
        }
        foreach ($image in $images) { $writer.Write([byte[]]$image) }
    } finally {
        $writer.Close()
    }
}

function New-TrayIcon([bool]$BreakTime) {
    $size = [math]::Max(16, [Windows.Forms.SystemInformation]::SmallIconSize.Width)
    $bitmap = New-AppIconBitmap $size $BreakTime
    [Drawing.Icon]::FromHandle($bitmap.GetHicon())
}

$script:RabbitRight = New-RabbitBitmap $true
$script:RabbitLeft = New-RabbitBitmap $false

if ($ExportIcon) {
    Save-AppIcon $ExportIcon
    exit
}

# ---------------------------------------------------------------------------
# Single instance and console handling
# ---------------------------------------------------------------------------

$script:Mutex = [Threading.Mutex]::new($false, 'Local\WalkBreak.Personal.Timer')
$ownsMutex = $false
try {
    $ownsMutex = $script:Mutex.WaitOne(0)
} catch [Threading.AbandonedMutexException] {
    $ownsMutex = $true
}
if (-not $ownsMutex) { exit }

# When started with "Run with PowerShell", hide the console window that came
# with it. Leave the window alone when someone runs the script from their own
# terminal session.
$consoleWindow = [WalkBreak.Native]::GetConsoleWindow()
if ($consoleWindow -ne [IntPtr]::Zero -and [WalkBreak.Native]::OwnsConsoleAlone()) {
    [void][WalkBreak.Native]::ShowWindow($consoleWindow, 0)
}

[Windows.Forms.Application]::EnableVisualStyles()
try { [Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false) } catch { }
try { [Windows.Forms.Application]::SetUnhandledExceptionMode([Windows.Forms.UnhandledExceptionMode]::CatchException) } catch { }
[Windows.Forms.Application]::add_ThreadException({
    param($sender, $e)
    Write-WalkBreakLog ("{0}`r`n{1}" -f $e.Exception.Message, $e.Exception.StackTrace)
})

# ---------------------------------------------------------------------------
# Look and feel
# ---------------------------------------------------------------------------

$script:Blue = ColorOf 0x173B75
$script:Cream = ColorOf 0xFAF2DE
$script:White = [Drawing.Color]::White

$script:FontHeader = New-Font 'Consolas' 14 Bold
$script:FontToggle = New-Font 'Consolas' 11 Bold
$script:FontStatus = New-Font 'Consolas' 12 Bold
$script:FontTimer = New-Font 'Consolas' 42 Bold
$script:FontNext = New-Font 'Consolas' 11
$script:FontButton = New-Font 'Consolas' 11 Bold
$script:FontTest = New-Font 'Consolas' 10 Bold
$script:FontBreakTimer = New-Font 'Consolas' 27 Bold
$script:FontIdeasTitle = New-Font 'Consolas' 13 Bold
$script:FontComplete = New-Font 'Consolas' 19 Bold
$script:FontIdea = New-Font 'Segoe UI' 13

$script:TextFlags = [Windows.Forms.TextFormatFlags]::NoPadding -bor [Windows.Forms.TextFormatFlags]::SingleLine -bor [Windows.Forms.TextFormatFlags]::NoPrefix

function Measure-Text($Graphics, [string]$Text, [Drawing.Font]$Font) {
    [Windows.Forms.TextRenderer]::MeasureText($Graphics, $Text, $Font, [Drawing.Size]::new(10000, 10000), $script:TextFlags)
}

function Draw-Text($Graphics, [string]$Text, [Drawing.Font]$Font, [Drawing.Color]$Color, [int]$X, [int]$Y) {
    [Windows.Forms.TextRenderer]::DrawText($Graphics, $Text, $Font, [Drawing.Point]::new($X, $Y), $Color, $script:TextFlags)
}

function Draw-TrackedText($Graphics, [string]$Text, [Drawing.Font]$Font, [Drawing.Color]$Color, [int]$X, [int]$CenterY, [double]$Tracking) {
    $cell = Measure-Text $Graphics 'W' $Font
    $y = $CenterY - (Div $cell.Height 2)
    foreach ($character in $Text.ToCharArray()) {
        if ($character -ne ' ') { Draw-Text $Graphics ([string]$character) $Font $Color $X $y }
        $X += $cell.Width + (Px $Tracking)
    }
}

function Get-TimerText {
    '{0:00}:{1:00}' -f (Div $script:Remaining 60), ($script:Remaining % 60)
}

function Get-StatusText {
    if ($script:Phase -eq 'walk') { return 'Movement break' }
    if ($script:Running) { 'Work session' } else { 'Ready to work' }
}

# ---------------------------------------------------------------------------
# Animated pixel scenes
# ---------------------------------------------------------------------------

$script:MeadowBase = New-MeadowBackground
$script:DeskBase = New-DeskBackground
$script:SceneViews = [Collections.ArrayList]::new()

$script:AnimationTimer = [Windows.Forms.Timer]::new()
$script:AnimationTimer.Interval = 42
$script:AnimationTimer.add_Tick({
    foreach ($view in @($script:SceneViews)) {
        if ($view.Animating) { Update-ScenePose $view }
    }
})

function Update-SceneFrame($View) {
    $g = $View.FrameGraphics
    if ($View.Kind -eq 'desk') {
        Draw-Sprite $g $script:DeskBase 0 0
        Paint-Pixels $g 0xFFF1DD 60 (33 + ($View.TypingFrame % 2)) 7 2
        Paint-Pixels $g 0xCBBBC5 63 (36 - (Div $View.TypingFrame 2)) 6 1
    } else {
        Draw-Sprite $g $script:MeadowBase 0 0
        $pose = $View.Pose
        Paint-Pixels $g 0x688A5A ($pose.X + 3) 46 13 1
        $sprite = if ($pose.FacingRight) { $script:RabbitRight } else { $script:RabbitLeft }
        Draw-Sprite $g $sprite $pose.X (31 - $pose.Lift)
    }
    $View.Panel.Invalidate()
}

function Update-ScenePose($View, [switch]$Force) {
    $elapsed = $View.Clock.Elapsed.TotalSeconds
    if ($View.Kind -eq 'desk') {
        $frame = ([int][math]::Floor($elapsed * 6)) % 4
        if (-not $Force -and $frame -eq $View.TypingFrame) { return }
        $View.TypingFrame = $frame
    } else {
        $pose = Get-RabbitPose $elapsed $View.ReduceMotion
        $same = $pose.X -eq $View.Pose.X -and $pose.Lift -eq $View.Pose.Lift -and $pose.FacingRight -eq $View.Pose.FacingRight
        if (-not $Force -and $same) { return }
        $View.Pose = $pose
    }
    Update-SceneFrame $View
}

function Update-AnimationTimer {
    $running = @($script:SceneViews | Where-Object { $_.Animating }).Count -gt 0
    $script:AnimationTimer.Enabled = $running
}

function Set-SceneAnimating($View, [bool]$Animate) {
    $View.ReduceMotion = -not [WalkBreak.Native]::AnimationsEnabled()
    if ($View.Kind -eq 'desk' -and $View.ReduceMotion) { $Animate = $false }
    if ($Animate) {
        if ($View.Animating) { return }
        $View.Animating = $true
        $View.Clock = [Diagnostics.Stopwatch]::StartNew()
        Update-ScenePose $View -Force
    } else {
        $View.Animating = $false
        $View.Pose = Get-RabbitPose 0 $true
        $View.TypingFrame = 0
        Update-SceneFrame $View
    }
    Update-AnimationTimer
}

function New-SceneView([Windows.Forms.Control]$Panel, [string]$Kind, [scriptblock]$Overlay) {
    $frame = [Drawing.Bitmap]::new(128, 52, [Drawing.Imaging.PixelFormat]::Format32bppArgb)
    $view = @{
        Panel = $Panel; Kind = $Kind; Frame = $frame; FrameGraphics = (New-SceneGraphics $frame)
        Animating = $false; ReduceMotion = $false; Clock = [Diagnostics.Stopwatch]::new()
        Pose = (Get-RabbitPose 0 $true); TypingFrame = 0; Overlay = $Overlay
    }
    $Panel.Tag = $view
    $Panel.add_Paint({
        param($sender, $e)
        $view = $sender.Tag
        $g = $e.Graphics
        $g.InterpolationMode = [Drawing.Drawing2D.InterpolationMode]::NearestNeighbor
        $g.PixelOffsetMode = [Drawing.Drawing2D.PixelOffsetMode]::Half
        $target = [Drawing.Rectangle]::new(0, 0, $sender.ClientSize.Width, $sender.ClientSize.Height)
        $attributes = [Drawing.Imaging.ImageAttributes]::new()
        $attributes.SetWrapMode([Drawing.Drawing2D.WrapMode]::TileFlipXY)
        $g.DrawImage($view.Frame, $target, 0, 0, 128, 52, [Drawing.GraphicsUnit]::Pixel, $attributes)
        $attributes.Dispose()
        $g.PixelOffsetMode = [Drawing.Drawing2D.PixelOffsetMode]::Default
        if ($view.Overlay) { & $view.Overlay $g $sender }
    })
    [void]$script:SceneViews.Add($view)
    Update-SceneFrame $view
    $view
}

# ---------------------------------------------------------------------------
# Shared controls
# ---------------------------------------------------------------------------

function New-Panel([int]$X, [int]$Y, [int]$Width, [int]$Height, [Drawing.Color]$Color) {
    $panel = [WalkBreak.BufferedPanel]::new()
    $panel.Location = [Drawing.Point]::new($X, $Y)
    $panel.Size = [Drawing.Size]::new($Width, $Height)
    $panel.BackColor = $Color
    $panel
}

function New-RetroButton([string]$Text) {
    $button = [Windows.Forms.Button]::new()
    $button.Text = $Text
    $button.Font = $script:FontButton
    $button.FlatStyle = [Windows.Forms.FlatStyle]::Flat
    $button.UseVisualStyleBackColor = $false
    $button.BackColor = ColorOf 0xFBF6E7
    $button.ForeColor = $script:Blue
    $button.FlatAppearance.BorderColor = $script:Blue
    $button.FlatAppearance.BorderSize = [math]::Max(1, (Px 1))
    $button.FlatAppearance.MouseOverBackColor = ColorOf 0xF1EADB
    $button.FlatAppearance.MouseDownBackColor = ColorOf 0xD1D1CB
    $button.Cursor = [Windows.Forms.Cursors]::Hand
    $textSize = [Windows.Forms.TextRenderer]::MeasureText($Text, $button.Font)
    $button.Size = [Drawing.Size]::new($textSize.Width + (Px 14), (Px 25))
    $button
}

function Draw-Meter($Graphics, [int]$X, [int]$Y, [int]$Width, [int]$Height) {
    $count = 18
    $duration = if ($script:Session) { [double]$script:Session.Duration } else { [double]$script:WorkSeconds }
    $filled = [int][math]::Ceiling($count * ($script:Remaining / $duration))
    $border = [math]::Max(1, (Px 1))
    $Graphics.FillRectangle((Get-Brush 0x173B75), $X, $Y, $Width, $Height)
    $Graphics.FillRectangle((Get-Brush 0xFAF2DE), $X + $border, $Y + $border, $Width - 2 * $border, $Height - 2 * $border)

    $inset = Px 2
    $gap = [double](Px 2)
    $innerX = $X + $inset
    $innerWidth = $Width - 2 * $inset
    $segment = ($innerWidth - $gap * ($count - 1)) / $count
    for ($i = 0; $i -lt $count; $i++) {
        $left = $innerX + [int][math]::Round($i * ($segment + $gap))
        $right = $innerX + [int][math]::Round($i * ($segment + $gap) + $segment)
        $color = if ($i -lt $filled) { 0x173B75 } else { 0xDDDAD0 }
        $Graphics.FillRectangle((Get-Brush $color), $left, $Y + $inset, $right - $left, $Height - 2 * $inset)
    }
}

# ---------------------------------------------------------------------------
# Tray panel (the equivalent of the menu-bar window on macOS)
# ---------------------------------------------------------------------------

function New-TrayPanel {
    $width = Px 318
    $inner = Px 308
    $form = [WalkBreak.PopupForm]::new($false)
    $form.Text = 'Walk Break'
    $form.BackColor = $script:Blue
    $form.ClientSize = [Drawing.Size]::new($width, (Px 323))
    $form.KeyPreview = $true

    $header = New-Panel (Px 5) 0 $inner (Px 40) $script:Blue
    $header.add_Paint({
        param($sender, $e)
        Draw-TrackedText $e.Graphics 'WALK BREAK' $script:FontHeader $script:White (Px 12) (Div $sender.Height 2) 2
    })

    $toggle = [Windows.Forms.Button]::new()
    $toggle.FlatStyle = [Windows.Forms.FlatStyle]::Flat
    $toggle.FlatAppearance.BorderSize = 0
    $toggle.Size = [Drawing.Size]::new((Px 57), (Px 24))
    $toggle.Location = [Drawing.Point]::new($inner - (Px 12) - $toggle.Width, (Px 8))
    $toggle.Cursor = [Windows.Forms.Cursors]::Hand
    $toggle.AccessibleName = 'Walk Break'
    $toggle.add_Paint({
        param($sender, $e)
        $g = $e.Graphics
        $g.Clear((ColorOf 0x133060))
        $border = [math]::Max(1, (Px 1))
        $pen = [Drawing.Pen]::new((ColorOf 0xA1ACBF), $border)
        $pen.Alignment = [Drawing.Drawing2D.PenAlignment]::Inset
        $g.DrawRectangle($pen, 0, 0, $sender.Width - 1, $sender.Height - 1)
        $pen.Dispose()
        $label = if ($script:Running) { 'ON' } else { 'OFF' }
        $square = Px 7
        $spacing = Px 5
        $size = Measure-Text $g $label $script:FontToggle
        $x = Div ($sender.Width - ($square + $spacing + $size.Width)) 2
        $light = if ($script:Running) { 0xB3D180 } else { 0x8493AC }
        $g.FillRectangle((Get-Brush $light), $x, (Div ($sender.Height - $square) 2), $square, $square)
        Draw-Text $g $label $script:FontToggle $script:White ($x + $square + $spacing) (Div ($sender.Height - $size.Height) 2)
    })
    $toggle.add_Click({ Set-WalkBreakEnabled (-not $script:Running) })
    $header.Controls.Add($toggle)

    $scene = New-Panel (Px 5) (Px 40) $inner (Px 130) $script:Cream

    $cream = New-Panel (Px 5) (Px 170) $inner (Px 148) $script:Cream
    $cream.add_Paint({
        param($sender, $e)
        $g = $e.Graphics
        Draw-Text $g (Get-StatusText) $script:FontStatus $script:Blue (Px 12) (Px 10)
        Draw-Text $g (Get-TimerText) $script:FontTimer $script:Blue (Px 10) (Px 26)
        if ($script:Running) {
            $next = if ($script:Phase -eq 'walk') { 'Next: work' } else { 'Next: break' }
            $size = Measure-Text $g $next $script:FontNext
            Draw-Text $g $next $script:FontNext $script:Blue ($sender.Width - (Px 12) - $size.Width) ((Px 69) - $size.Height)
        }
        Draw-Meter $g (Px 12) (Px 86) ($sender.Width - (Px 24)) (Px 11)
    })

    $test = New-RetroButton ('Test cycle {0} 25 sec' -f [char]0x00B7)
    $test.Location = [Drawing.Point]::new((Px 12), (Px 111))
    $test.add_Click({ Start-WalkBreak $true })
    $cream.Controls.Add($test)

    $quit = New-RetroButton 'Quit'
    $quit.Location = [Drawing.Point]::new($inner - (Px 12) - $quit.Width, (Px 111))
    $quit.add_Click({ Exit-WalkBreak })
    $cream.Controls.Add($quit)

    $form.Controls.AddRange(@($header, $scene, $cream))
    $form.add_Deactivate({ Hide-TrayPanel })
    $form.add_KeyDown({
        param($sender, $e)
        if ($e.KeyCode -eq [Windows.Forms.Keys]::Escape) { Hide-TrayPanel }
        if ($e.Control -and $e.KeyCode -eq [Windows.Forms.Keys]::Q) { Exit-WalkBreak }
    })

    $script:TrayPanel = $form
    $script:TrayToggle = $toggle
    $script:TrayCream = $cream
    $script:TrayTestButton = $test
    $script:TrayScene = New-SceneView $scene 'desk' $null
}

function Update-TrayScene {
    $view = $script:TrayScene
    $kind = if ($script:Phase -eq 'walk') { 'meadow' } else { 'desk' }
    $visible = $script:TrayPanel.Visible
    $animate = if ($kind -eq 'meadow') { $visible } else { $visible -and $script:Running }
    if ($view.Kind -ne $kind) {
        Set-SceneAnimating $view $false
        $view.Kind = $kind
    }
    Set-SceneAnimating $view $animate
}

function Show-TrayPanel {
    $form = $script:TrayPanel
    $cursor = [Windows.Forms.Cursor]::Position
    $screen = [Windows.Forms.Screen]::FromPoint($cursor)
    $area = $screen.WorkingArea
    $margin = Px 8
    $x = [math]::Min([math]::Max($cursor.X - (Div $form.Width 2), $area.Left + $margin), $area.Right - $form.Width - $margin)
    $y = if ($area.Top -gt $screen.Bounds.Top) { $area.Top + $margin } else { $area.Bottom - $form.Height - $margin }
    $form.Location = [Drawing.Point]::new($x, $y)
    $script:TrayTestButton.Enabled = -not $script:Running
    $form.Show()
    $form.Activate()
    [void][WalkBreak.Native]::SetForegroundWindow($form.Handle)
    Update-TrayScene
    $script:TrayCream.Invalidate()
    $script:TrayToggle.Invalidate()
}

function Hide-TrayPanel {
    if ($script:TrayPanel.Visible) {
        $script:TrayPanel.Hide()
        $script:TrayPanelHiddenAt = [datetime]::UtcNow
    }
    Update-TrayScene
}

# ---------------------------------------------------------------------------
# Break window (the equivalent of BreakPanel.swift)
# ---------------------------------------------------------------------------

function New-BreakWindow {
    $width = Px 384
    $inner = Px 374
    $form = [WalkBreak.PopupForm]::new($true)
    $form.Text = 'Walk Break'
    $form.BackColor = $script:Blue
    $form.ClientSize = [Drawing.Size]::new($width, (Px 322))

    $header = New-Panel 0 0 $width (Px 40) $script:Blue
    $close = New-Panel ($width - (Px 12) - (Px 30)) (Px 7) (Px 30) (Px 26) $script:Blue
    $close.Cursor = [Windows.Forms.Cursors]::Hand
    $close.AccessibleName = 'Close break window'
    $close.AccessibleRole = [Windows.Forms.AccessibleRole]::PushButton
    $close.add_Paint({
        param($sender, $e)
        $g = $e.Graphics
        $g.SmoothingMode = [Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $path = New-RoundedPath 0 0 ($sender.Width - 1) ($sender.Height - 1) (Px 4)
        $g.FillPath((Get-Brush 0xB5294F), $path)
        $path.Dispose()
        $pen = [Drawing.Pen]::new($script:White, [single](2.2 * $script:Scale))
        $pen.StartCap = [Drawing.Drawing2D.LineCap]::Square
        $pen.EndCap = [Drawing.Drawing2D.LineCap]::Square
        $half = 4.5 * $script:Scale
        $cx = $sender.Width / 2.0
        $cy = $sender.Height / 2.0
        $g.DrawLine($pen, [single]($cx - $half), [single]($cy - $half), [single]($cx + $half), [single]($cy + $half))
        $g.DrawLine($pen, [single]($cx + $half), [single]($cy - $half), [single]($cx - $half), [single]($cy + $half))
        $pen.Dispose()
    })
    $close.add_MouseClick({ Hide-BreakWindow })
    $header.Controls.Add($close)
    $header.Tag = $close
    $header.add_Paint({
        param($sender, $e)
        $g = $e.Graphics
        Draw-TrackedText $g 'WALK BREAK' $script:FontHeader $script:White (Px 12) (Div $sender.Height 2) 2
        if ($script:IsTestPresentation) {
            $size = Measure-Text $g 'TEST' $script:FontTest
            Draw-Text $g 'TEST' $script:FontTest $script:White ($sender.Tag.Left - (Px 8) - $size.Width) (Div ($sender.Height - $size.Height) 2)
        }
    })

    $scene = New-Panel (Px 5) (Px 40) $inner (Px 154) $script:Cream
    $overlay = {
        param($g, $panel)
        if ($script:Phase -ne 'walk') { return }
        $text = Get-TimerText
        $size = Measure-Text $g $text $script:FontBreakTimer
        $box = [Drawing.Rectangle]::new((Px 10), (Px 10), $size.Width + (Px 18), $size.Height + (Px 8))
        $g.FillRectangle((Get-Brush 0xFAF2DE), $box)
        Draw-Text $g $text $script:FontBreakTimer $script:Blue ($box.X + (Px 9)) ($box.Y + (Px 4))
    }

    $bottom = New-Panel (Px 5) (Px 194) $inner (Px 123) $script:Cream
    $bottom.add_Paint({
        param($sender, $e)
        $g = $e.Graphics
        $x = Px 15
        if ($script:Phase -eq 'walk') {
            $titleHeight = (Measure-Text $g 'Ag' $script:FontIdeasTitle).Height
            $rowHeight = (Measure-Text $g 'Ag' $script:FontIdea).Height
            $ideas = @($script:Ideas)
            $total = $titleHeight + $ideas.Count * ((Px 6) + $rowHeight)
            $y = Div ($sender.Height - $total) 2
            Draw-Text $g 'Movement ideas' $script:FontIdeasTitle $script:Blue $x $y
            $y += $titleHeight
            foreach ($idea in $ideas) {
                $y += Px 6
                $dot = Px 5
                $g.FillRectangle((Get-Brush 0x42734F), $x, $y + (Div ($rowHeight - $dot) 2), $dot, $dot)
                Draw-Text $g $idea $script:FontIdea $script:Blue ($x + $dot + (Px 8)) $y
                $y += $rowHeight
            }
        } else {
            $title = 'Break complete'
            $line = 'Back to work {0} 40-minute timer started' -f [char]0x00B7
            $titleHeight = (Measure-Text $g $title $script:FontComplete).Height
            $lineHeight = (Measure-Text $g $line $script:FontIdea).Height
            $y = Div ($sender.Height - ($titleHeight + (Px 6) + $lineHeight)) 2
            Draw-Text $g $title $script:FontComplete $script:Blue $x $y
            Draw-Text $g $line $script:FontIdea $script:Blue $x ($y + $titleHeight + (Px 6))
        }
    })

    $form.Controls.AddRange(@($header, $scene, $bottom))
    $script:BreakWindow = $form
    $script:BreakHeader = $header
    $script:BreakBottom = $bottom
    $script:BreakScene = New-SceneView $scene 'meadow' $overlay
}

function Update-BreakWindow {
    $script:BreakHeader.Invalidate()
    $script:BreakBottom.Invalidate()
    $script:BreakScene.Panel.Invalidate()
    Set-SceneAnimating $script:BreakScene ($script:Phase -eq 'walk' -and $script:IsBreakWindowVisible)
}

function Show-BreakWindow {
    $form = $script:BreakWindow
    if (-not $form.Visible) {
        $screen = [Windows.Forms.Screen]::FromPoint([Windows.Forms.Cursor]::Position)
        $area = $screen.WorkingArea
        $form.Location = [Drawing.Point]::new($area.Right - $form.Width - (Px 24), $area.Bottom - $form.Height - (Px 24))
        $form.Show()
    }
    $script:IsBreakWindowVisible = $true
    Update-BreakWindow
}

function Hide-BreakWindow {
    $script:BreakWindow.Hide()
    $script:IsBreakWindowVisible = $false
    Update-BreakWindow
}

# ---------------------------------------------------------------------------
# Timer model (the equivalent of BreakTimer in WalkBreakApp.swift)
# ---------------------------------------------------------------------------

$script:Phase = $null
$script:Remaining = $script:WorkSeconds
$script:Running = $false
$script:Ideas = @()
$script:IsBreakWindowVisible = $false
$script:IsTestPresentation = $false
$script:IsTestCycle = $false
$script:TrayPanelHiddenAt = [datetime]::MinValue

$script:TickTimer = [Windows.Forms.Timer]::new()
$script:TickTimer.Interval = 250
$script:TickTimer.add_Tick({ Invoke-Tick })

function Send-PhaseNotification([string]$Phase, [bool]$IsTest) {
    if ($Phase -eq 'walk') {
        $title = if ($IsTest) { 'Test break started' } else { 'Time to stand up' }
        $body = if ($IsTest) { 'Your 20-second test countdown is running.' } else { 'Your 5-minute movement break has started.' }
    } else {
        $title = if ($IsTest) { 'Test break complete' } else { 'Back to work' }
        $body = 'Your next 40-minute work session has started.'
    }
    try {
        $script:Tray.ShowBalloonTip(5000, $title, $body, [Windows.Forms.ToolTipIcon]::None)
    } catch {
        Write-WalkBreakLog "Notification failed: $($_.Exception.Message)"
    }
}

function Update-Display {
    $now = [datetime]::UtcNow
    $phase = if ($script:Session) { $script:Session.Phase } else { $null }
    $remaining = Get-SecondsRemaining $now
    $phaseChanged = $phase -ne $script:Phase
    $timeChanged = $remaining -ne $script:Remaining
    $script:Phase = $phase
    $script:Remaining = $remaining

    if ($phaseChanged) {
        $script:Tray.Icon = if ($phase -eq 'walk') { $script:IconBreak } else { $script:IconWork }
        $script:TrayToggle.Invalidate()
        $script:TrayTestButton.Enabled = -not $script:Running
        Update-TrayScene
    }
    if ($phaseChanged -or $timeChanged) {
        $script:Tray.Text = if ($script:Running) { 'Walk Break: {0}, {1} left' -f (Get-StatusText).ToLower(), (Get-TimerText) } else { 'Walk Break: off' }
        if ($script:TrayPanel.Visible) { $script:TrayCream.Invalidate() }
        if ($script:IsBreakWindowVisible) {
            $script:BreakScene.Panel.Invalidate()
            if ($phaseChanged) { Update-BreakWindow }
        }
    }
}

function Start-WalkBreak([bool]$Test) {
    if ($script:Running) { return }
    $script:IsTestCycle = $Test
    Start-Cycle ([datetime]::UtcNow) $Test
    $script:Running = $true
    $script:TickTimer.Start()
    Update-Display
}

function Set-WalkBreakEnabled([bool]$Enabled) {
    if ($Enabled) {
        Start-WalkBreak $false
    } else {
        $script:TickTimer.Stop()
        $script:Running = $false
        Stop-Cycle
        Hide-BreakWindow
        Update-Display
    }
}

function Invoke-Tick {
    try {
        $now = [datetime]::UtcNow
        $next = Step-CycleIfDue $now
        Update-Display
        if ($null -eq $next) { return }

        $script:IsTestPresentation = $script:IsTestCycle
        if ($next -eq 'walk') {
            $script:Ideas = @(Get-NextMovements $script:IsTestCycle)
        } else {
            $script:IsTestCycle = $false
        }
        Show-BreakWindow
        Send-PhaseNotification $next $script:IsTestPresentation
    } catch {
        Write-WalkBreakLog ("Tick failed: {0}`r`n{1}" -f $_.Exception.Message, $_.ScriptStackTrace)
    }
}

function Exit-WalkBreak {
    $script:TickTimer.Stop()
    $script:AnimationTimer.Stop()
    $script:Tray.Visible = $false
    $script:Tray.Dispose()
    [Windows.Forms.Application]::Exit()
}

# ---------------------------------------------------------------------------
# Tray icon and start-up
# ---------------------------------------------------------------------------

$script:IconWork = New-TrayIcon $false
$script:IconBreak = New-TrayIcon $true

New-TrayPanel
New-BreakWindow

$menu = [Windows.Forms.ContextMenuStrip]::new()
$openItem = $menu.Items.Add('Open Walk Break')
$openItem.Font = [Drawing.Font]::new($openItem.Font, [Drawing.FontStyle]::Bold)
$openItem.add_Click({ Show-TrayPanel })
$script:MenuToggle = $menu.Items.Add('Turn on')
$script:MenuToggle.add_Click({ Set-WalkBreakEnabled (-not $script:Running) })
$script:MenuTest = $menu.Items.Add(('Test cycle {0} 25 sec' -f [char]0x00B7))
$script:MenuTest.add_Click({ Start-WalkBreak $true })
[void]$menu.Items.Add([Windows.Forms.ToolStripSeparator]::new())
$quitItem = $menu.Items.Add('Quit')
$quitItem.add_Click({ Exit-WalkBreak })
$menu.add_Opening({
    $script:MenuToggle.Text = if ($script:Running) { 'Turn off' } else { 'Turn on' }
    $script:MenuTest.Enabled = -not $script:Running
})

$script:Tray = [Windows.Forms.NotifyIcon]::new()
$script:Tray.Icon = $script:IconWork
$script:Tray.Text = 'Walk Break: off'
$script:Tray.ContextMenuStrip = $menu
$script:Tray.add_MouseClick({
    param($sender, $e)
    if ($e.Button -ne [Windows.Forms.MouseButtons]::Left) { return }
    if ($script:TrayPanel.Visible) { Hide-TrayPanel; return }
    # A click on the tray icon first deactivates the open panel. Don't reopen it.
    if (([datetime]::UtcNow - $script:TrayPanelHiddenAt).TotalMilliseconds -lt 300) { return }
    Show-TrayPanel
})
$script:Tray.Visible = $true

$welcomeFile = Join-Path $script:DataDir 'welcomed'
if (-not (Test-Path -LiteralPath $welcomeFile)) {
    $script:Tray.ShowBalloonTip(8000, 'Walk Break is running',
        'Click the rabbit icon in the system tray and switch Walk Break on.', [Windows.Forms.ToolTipIcon]::None)
    try {
        New-Item -ItemType Directory -Force -Path $script:DataDir | Out-Null
        Set-Content -LiteralPath $welcomeFile -Value (Get-Date -Format o)
    } catch {
    }
}

Write-WalkBreakLog 'Walk Break started'
[Windows.Forms.Application]::Run([Windows.Forms.ApplicationContext]::new())
$script:Mutex.ReleaseMutex()
