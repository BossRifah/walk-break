<#
.SYNOPSIS
    Removes Walk Break for the current Windows user.

.PARAMETER KeepSettings
    Keep the movement rotation and log in %APPDATA%\WalkBreak.
#>
[CmdletBinding()]
param(
    [switch]$KeepSettings
)

$ErrorActionPreference = 'Stop'

$installDir = Join-Path $env:LOCALAPPDATA 'Programs\WalkBreak'
$dataDir = Join-Path $env:APPDATA 'WalkBreak'
$links = @(
    (Join-Path ([Environment]::GetFolderPath('Programs')) 'Walk Break.lnk'),
    (Join-Path ([Environment]::GetFolderPath('Startup')) 'Walk Break.lnk')
)

Write-Host 'Removing Walk Break...'

Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" |
    Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like '*WalkBreak.ps1*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 500

foreach ($link in $links) {
    if (Test-Path -LiteralPath $link) { Remove-Item -LiteralPath $link -Force }
}
if (Test-Path -LiteralPath $installDir) { Remove-Item -LiteralPath $installDir -Recurse -Force }
if (-not $KeepSettings -and (Test-Path -LiteralPath $dataDir)) { Remove-Item -LiteralPath $dataDir -Recurse -Force }

Write-Host 'Walk Break has been removed.'
