<#
.SYNOPSIS
    Installs Walk Break for the current Windows user. No administrator rights needed.

.PARAMETER StartWithWindows
    Start Walk Break automatically when you sign in, without asking.

.PARAMETER NoStartWithWindows
    Don't start Walk Break when you sign in, without asking.

.PARAMETER NoLaunch
    Install without opening Walk Break afterwards.
#>
[CmdletBinding()]
param(
    [switch]$StartWithWindows,
    [switch]$NoStartWithWindows,
    [switch]$NoLaunch
)

$ErrorActionPreference = 'Stop'

$source = Join-Path $PSScriptRoot 'WalkBreak.ps1'
if (-not (Test-Path -LiteralPath $source)) {
    throw "WalkBreak.ps1 was not found next to install.ps1. Keep both files in the same folder."
}

$installDir = Join-Path $env:LOCALAPPDATA 'Programs\WalkBreak'
$target = Join-Path $installDir 'WalkBreak.ps1'
$iconPath = Join-Path $installDir 'WalkBreak.ico'
$windowsPowerShell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$conhost = Join-Path $env:SystemRoot 'System32\conhost.exe'
$startMenuLink = Join-Path ([Environment]::GetFolderPath('Programs')) 'Walk Break.lnk'
$startupLink = Join-Path ([Environment]::GetFolderPath('Startup')) 'Walk Break.lnk'

Write-Host 'Installing Walk Break...'

# Close a running copy so the file can be replaced.
Get-CimInstance Win32_Process -Filter "Name = 'powershell.exe'" |
    Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -like '*WalkBreak.ps1*' } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }

New-Item -ItemType Directory -Force -Path $installDir | Out-Null
Copy-Item -LiteralPath $source -Destination $target -Force
Unblock-File -LiteralPath $target

& $windowsPowerShell -NoProfile -ExecutionPolicy Bypass -STA -File $target -ExportIcon $iconPath
if (-not (Test-Path -LiteralPath $iconPath)) {
    Write-Warning 'The icon could not be created. Shortcuts will use the PowerShell icon.'
    $iconPath = "$windowsPowerShell"
}

# conhost --headless runs PowerShell without any console window, even on
# Windows 11 where Windows Terminal is the default terminal.
function New-WalkBreakShortcut([string]$Path) {
    $shell = New-Object -ComObject WScript.Shell
    $link = $shell.CreateShortcut($Path)
    $link.TargetPath = $conhost
    $link.Arguments = "--headless `"$windowsPowerShell`" -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File `"$target`""
    $link.WorkingDirectory = $installDir
    $link.IconLocation = "$iconPath,0"
    $link.Description = 'Walk Break: 40 minutes of work, then a 5-minute movement break'
    $link.WindowStyle = 7
    $link.Save()
}

New-WalkBreakShortcut $startMenuLink
Write-Host "Added Walk Break to the Start menu."

$autoStart = $false
if ($StartWithWindows) {
    $autoStart = $true
} elseif (-not $NoStartWithWindows) {
    $answer = Read-Host 'Start Walk Break automatically when you sign in to Windows? (Y/N)'
    $autoStart = $answer -match '^\s*y'
}

if ($autoStart) {
    New-WalkBreakShortcut $startupLink
    Write-Host 'Walk Break will start when you sign in.'
} elseif (Test-Path -LiteralPath $startupLink) {
    Remove-Item -LiteralPath $startupLink -Force
}

if (-not $NoLaunch) {
    Start-Process -FilePath $startMenuLink
    Write-Host 'Walk Break is running. Look for the rabbit icon in the system tray.'
    Write-Host 'On Windows 11 it may be inside the ^ overflow area next to the clock.'
}

Write-Host ''
Write-Host "Installed to $installDir"
